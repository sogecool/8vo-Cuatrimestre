import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/movie.dart';

Future<List<Movie>> fetchMovies() async {
  final url = 'https://api.watchmode.com/v1/releases/?apiKey=YgksP9RN7WKiJmtuImLsdax9xrKkIaqBA1IyZQYD';
  final response = await http.get(Uri.parse(url));

  if (response.statusCode == 200) {
    final data = json.decode(response.body);
    final List releases = data['releases'];
    return releases.map((json) => Movie.fromJson(json)).toList();
  } else {
    throw Exception('Error al obtener los datos');
  }
}
