import 'package:flutter/material.dart';

class Memorie extends StatefulWidget {
  const Memorie({super.key});

  @override
  State<Memorie> createState() => _MemorieState();
}

class _MemorieState extends State<Memorie> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}