import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'LoadingPage.dart';


class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {

  void Logeame() {
    SharedPreferences.getInstance().then((prefs) {
      prefs.setBool('tas_logeado', true);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Loadingpage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900], // Fondo negro
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 100.0, left: 20.0, right: 20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 150.0),
                child: const Text(
                  'Watch A Film',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white, // Letras blancas
                  ),
                ),
              ),
              const Text(
                'Sign Up',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white, // Letras blancas
                ),
              ),
              const Text(
                'Enter your email to sign up for this app',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.normal,
                  color: Colors.grey, // Letras blancas
                ),
              ),
              const SizedBox(height: 30),

              // Campo de correo
              TextField(
                keyboardType: TextInputType.emailAddress,
                style: const TextStyle(color: Colors.white), // Texto blanco
                decoration: InputDecoration(
                  labelText: 'example@gmail.com',
                  labelStyle: const TextStyle(color: Colors.grey), // Etiqueta blanca
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.grey), // Borde blanco
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.blue), // Borde azul al seleccionar
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Campo de contraseña


              // Botón de login
              GestureDetector(
                onTap: Logeame,
                child: Container(
                  height: 60,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white, // Fondo blanco
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Center(
                    child: Text(
                      "Login",
                      style: TextStyle(
                        color: Colors.black, // Texto negro
                        fontSize: 20,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}