import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/trending_silder.dart';
import 'LoadingPage.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  void DesLogeame() {
    SharedPreferences.getInstance().then((prefs) {
      prefs.setBool('tas_logeado', false);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const Loadingpage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        backgroundColor: Colors.grey[800], // Fondo negro para la barra superior
        title: const Text(
          'Watch a Film',
          style: TextStyle(
            color: Colors.white,
            fontSize: 30,
            fontWeight: FontWeight.bold,
          ), // Texto blanco en la AppBar
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white), // Icono de logout
            onPressed: () {
              DesLogeame(); // También cierra sesión al presionar logout
            },
          ),
        ],
        elevation: 0, // Quita la sombra de la AppBar
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 30.0,bottom: 5.0),
              child: Text("New this Week",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  )),
            ),
            Text("Watch a new movie today!",
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.white70,
                )),
            const SizedBox(height: 25.00),
            const TrendingSlider(),
            const SizedBox(height: 20.00),

          ],
        ),
      ),
    );
  }
}

