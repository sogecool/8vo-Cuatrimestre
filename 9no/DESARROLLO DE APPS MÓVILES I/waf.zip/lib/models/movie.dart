class Movie {
  final String title;
  final String imageUrl;
  final String platform;
  final String releaseDate;

  Movie({
    required this.title,
    required this.imageUrl,
    required this.platform,
    required this.releaseDate,
  });

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      title: json['title'] ?? 'Sin título',
      imageUrl: json['poster_url'] ?? '',
      platform: json['source_name'] ?? 'Desconocida',
      releaseDate: json['source_release_date'] ?? 'Sin fecha',
    );
  }
}
