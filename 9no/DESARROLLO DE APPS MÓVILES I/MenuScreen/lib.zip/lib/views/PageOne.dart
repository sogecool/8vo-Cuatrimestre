import 'package:flutter/material.dart';

class PageOne extends StatelessWidget {
  const PageOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
      ),
      body: Column(
              children: [
                Container(
                  color: Colors.blue,
                  height: 100,
                  width: 200,
                ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children:  [
                Cubito(
                  height: 100,
                  width: 50,
                ),
                Cubito(
                  height: 100,
                  width: 50,
                ),

              ]
          )
        ],
      ),
    );
  }
}

class Cubito extends StatelessWidget {
  final double height;
  final double width;
  final Color? color;
  final double? radius;

  const Cubito({
    super.key,
    required this.height,
    required this.width,
    this.color,
    this.radius,
  });


  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      width: 100,
      decoration: BoxDecoration(
        color: color?? Colors.green,
        borderRadius: BorderRadius.circular(radius??15),
        border: Border.all(
          color: Colors.black,
          width: 10,
        )
      ),
    );
  }
}

