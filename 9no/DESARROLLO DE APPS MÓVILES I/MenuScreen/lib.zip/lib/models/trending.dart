class Trending {
  String category;
  String hashtag;
  String published;

  Trending({
    required this.category,
    required this.hashtag,
    required this.published,
  });
}