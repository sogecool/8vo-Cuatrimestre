import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../models/facts_cats.dart';
import '../services/api.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

  late Future<FactsCats> future;

  @override
  void initState() {
    super.initState();
    future = getFacts();
  }

  void refresh() {
    setState(() {
      future = getFacts();
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Gatitos (Aaron Hdez)',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              letterSpacing: 5,
              fontWeight: FontWeight.bold,
            ),
          ),
          centerTitle: true,
          backgroundColor: Colors.deepPurpleAccent.withAlpha(100),
        ),
        body: FutureBuilder<FactsCats>(
          future: future,
          builder: (context, dataSnapshot) {
            if (dataSnapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: Lottie.asset(
                  'assets/jsons/cat1.json',
                  width: 200,
                  height: 200,
                  fit: BoxFit.fill,
                ),
              );
            } else {
              if (dataSnapshot.error != null) {
                return Center(
                  child: Text('An error occured'),
                );
              } else {
                return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const SizedBox(width: double.infinity),
                      Container(
                        height: 400,
                        margin: const EdgeInsets.only(bottom: 50),
                        width: MediaQuery.of(context).size.width*0.8,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.deepPurpleAccent.withAlpha(100),
                              width: 3,
                            )
                        ),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Text(
                                  "Fact # ${dataSnapshot.data!.length}",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 30,
                                  ),
                                ),
                              ],
                            ),
                            const Spacer(),
                            Text(dataSnapshot.data!.fact),
                            const Spacer(),
                            Lottie.asset(
                              'assets/jsons/cat2.json',
                              width: 150,
                              height: 150,
                              fit: BoxFit.fill,
                            ),

                          ],
                        ),
                      ),
                    ]
                );
              }
            }
          },
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: refresh,
          tooltip: 'Increment',
          child: const Icon(Icons.refresh),
        )
    );
  }
}