class FactsCats{
  String fact;
  int length;

  FactsCats({
    required this.fact,
    required this.length,
  });

  factory FactsCats.fromJson(Map<String, dynamic> json) {
    return FactsCats(
      fact: json['fact'],
      length: json['length'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'fact': fact,
      'length': length,
    };
  }
}