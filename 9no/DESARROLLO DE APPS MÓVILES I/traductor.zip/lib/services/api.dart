import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:translator/translator.dart';
import '../models/facts_cats.dart';

Future<FactsCats> getFacts() async {

  await Future.delayed(const Duration(milliseconds: 500));

  final headers = {
    'Authorization': 'bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEiLCJleHAiOjE3NDE5MTM3OTEsImlzcyI6Ik1pQXBsaWNhY2lvbiJ9.WX0ZtggSBvcGNHNRmv6RUzH7B3mIsMHmdOq_bJiMHXQ',
    'Cookie': '5WBUJvS9QRjVSnuU8wMHdaGdqRrhqEbHWBLe6Zxr=eyJpdiI6InNoQkN6dVFZOWZPU0RHek9JbWNZQ1E9PSIsInZhbHVlIjoiMTdOVm1lSHFLbytMYm5WRXJkdkI2ZFA3Y3pHSzhvSnpXUVpTK0xQTWJqdmZhWnNwUGlJQ0laanVTUlo2WXBQVlpFQ0t2TmNST2tEbzFRd0MvZnk3UmtSK3hWTFIrYisxcGU1bnd3SFVzNmhXVmlrV2l4WUpSdm5vYy9tZDdjMUpiQlExclFKZjdFVHQ0dUtlZTNtSHBzMlBRamVDbmZNazNuOUxCbGdmR01KcitjZW0xVzFJYXQrZXZPR0lRTjlWRDlEdlRwWllUUTY0RU5Tb0dwTGNzNW9hcHdQMFYzdHRPMndCQURpYkJkQXJHVTAwRzdYTVN1b0orMy9xaGk3RjNLSnJDVzUzZytQaUttMTBac0w1YmRwKyszQm9TZmdYNHhFWEVKTzlOWXQ0cEthSzNvMlNvZmkzOU9JTDRsWGMrMnlTN3BYdWtlNWlFTnhOSkpsM3lCaFBoaE92eS9sVVRSeVZwa3JBOE5rRlZMQ01RQmE4SkpTaE9LQzl2enlVIiwibWFjIjoiODNjZWNjN2UyNzdkYzlmMjM0OThhMDJjOWZhZGMyYzI0N2E3N2Y4YWFjYThkYThiYTMxNGM1ZGU5OWViMzgwNCIsInRhZyI6IiJ9; XSRF-TOKEN=eyJpdiI6InV0NWhTRTdhZnM1clFJWG5XOVhQUVE9PSIsInZhbHVlIjoiRzlIMmMrN1hLRlBWNVQ5Zy8zRkJnYzhaelR1aW1VL3plbWt6VWs5WllZNStvWVB0dUxtdzk2YmVoY0NBRXZDd0lvS0NsTVp0ZlFGcjJjWmZ1ZWs4V0E3aG9CYUo4WE5mZUFQYzh3NUZPMUxvU0FBM0p0K3l5ck5OeDluNnFvcEsiLCJtYWMiOiJjZjM0NjMyNmE3NzJiN2EyNmM0ZWE2Y2ExYjU5MzY2M2FjN2I4YzY2ZmJmNjg4Y2YxNWNmY2ZlY2M1YzYxYTlkIiwidGFnIjoiIn0%3D; catfacts_session=eyJpdiI6IkZUMFNYWUgyZ0NhSkdtZW1lU2hON2c9PSIsInZhbHVlIjoiZzVRMS9JVngvenlmSTNJdm9ZWHFVTVExY2ltSXplVU15ZlpiV1lPSXNvMnRpMDB0U1EyanNIaUFyS1c3N3oycGdMdnRzUzFLS09ZMjFFTS9nRVZET1QxdkJ2M0dWOHYvRDRuQXhBVUZnZnp3azFGdU1rUHlrVWpEQWRxcUg4YTMiLCJtYWMiOiJjYzc5Y2M5ZDA4OWYwMjQyNWM2YzY3N2YwZmJlZmJlYTA1N2MxMjNjYmQ4NjIyNzNlZWZjYjliMmExZDNjY2JiIiwidGFnIjoiIn0%3D',
  };

  final url = Uri.parse('https://catfact.ninja/fact');

  final res = await http.get(url, headers: headers);
  final status = res.statusCode;
  if (status != 200) throw Exception('http.get error: statusCode= $status');

  final responseBody = jsonDecode(res.body);
  String factInEnglish = responseBody['fact'];

  //Aquí agregamos el Traductor de Google para traducir la respuesra de la API
  //Aarón Hdez -> 20/03/2025
  final translator = GoogleTranslator();
  String factInSpanish = (await translator.translate(factInEnglish, to: 'es')).text;

  return FactsCats(fact: factInSpanish, length: factInSpanish.length);

}